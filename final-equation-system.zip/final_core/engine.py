from final_core.interpreter import recursive_sum

def execute_final_equation(recursion_depth=1000):
    return recursive_sum("Ω†BLACK", "χ′", "TΩ", "Ψ", "K∞", "Ω†Σ", recursion_depth)
