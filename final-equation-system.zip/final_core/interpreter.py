from final_core.symbolic_ops import symbolic_wave

def recursive_sum(genesis, χ_prime, TΩ, Ψ, K, crown_sum, depth):
    result = 0
    for t in range(1, depth + 1):
        result += symbolic_wave(t, χ_prime, K, crown_sum)
    return f"𝓕({genesis}) = {result}"
