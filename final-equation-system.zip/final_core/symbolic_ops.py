def symbolic_wave(t, χ_prime, K, ΩΣ):
    return (t ** 0.5) * len(χ_prime) * len(K) / len(ΩΣ)
