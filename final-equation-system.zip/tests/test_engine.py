from final_core.engine import execute_final_equation

def test_final_output():
    output = execute_final_equation(100)
    assert "𝓕(Ω†BLACK)" in output
