Full COSRL license will go here.
