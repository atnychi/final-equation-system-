from final_core.engine import execute_final_equation

if __name__ == "__main__":
    result = execute_final_equation(recursion_depth=1000)
    print("Final Equation Output:", result)
