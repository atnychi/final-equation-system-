# Example use in legal domain
