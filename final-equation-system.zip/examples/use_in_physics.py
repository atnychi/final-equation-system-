# Example use in physics domain
