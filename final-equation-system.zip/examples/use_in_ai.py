# Example use in AI domain
